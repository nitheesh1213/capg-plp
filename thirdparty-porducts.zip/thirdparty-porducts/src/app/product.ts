export class product
{
   
 name: string;
 discription:string;
 price:number;
 
}