import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

import { merchant } from "./merchant";
import { Observable } from "rxjs/internal/Observable";
@Injectable({
  providedIn: 'root'
})
export class InventoryServiceService {

  constructor(private httpClient: HttpClient) {} //this.showMerchants().subscribe(data => this.merchantList = data);}
  // merchantList:Array<merchant>=[];

baseUrl = 'http://localhost:8070/produc';
//id:number;

  public showMerchants(): Observable<any> {
    //console.log("http://localhost:8050/merchants");
    return this.httpClient.get<any>("http://localhost:8060/getdetails");
  }



  public showProducts(mid): Observable<any> {console.log(mid);
    
    //this.id=mid;
    return this.httpClient.get<any>(`${this.baseUrl}/${mid}` );
  }
  
  // public deleteEmployee(id: number): Observable<void> {
  //   console.log(id);

  //   return this.httpClient.delete<void>(`${this.baseUrl}/${id}`)
   
  // }


  // public showProducts(id): Observable<any> {
  //   //console.log("http://localhost:8050/merchants");
  //   return this.httpClient.get<any>("http://localhost:8050/getdetails");
  // }
}


