import { Component } from "@angular/core";
import { merchant } from "./merchant";
import { InventoryServiceService } from "./inventory-service.service";
import { product } from "./product";
@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent {
  //merchantList: Array< merchant> = [];
  merchant: merchant;
product : product;
proceed:boolean=false;
  constructor(private merchantService: InventoryServiceService) {
    //this.merchantList= this.merchantService.merchantList
  }

  ngOnInit() {
    this.showMerchants();
  }
  showMerchants() {
    this.merchantService
      .showMerchants()
      .subscribe(data => (this.merchant = data));
    //  console.log(this.merchant);
  }
  // delete(code: number) {
  //   this.merchantService.deleteEmployee(code).subscribe(data => {
  //     alert("merchant added successfully.");
  //     this.reload();
  //     });
  //    // this.reload();
  //     //.subscribe(data => (this.merchant = data));
  //   //this.employeeList= this.employeeService.EmployeeList;
  // }
  reload() {
   this.showMerchants();
  }

  showProducts(data) {
    this.proceed=true;
    this.merchantService.showProducts(data.mid).subscribe(data1 => {this.product = data1;
      alert("click on ok to display products");this.proceed=true;
    });
  }
}
