export class merchant
{
    mid: number;
 tmname: string;
 tmmobile : number;
 tmmail:string;
 tmaddress:string;
 
}