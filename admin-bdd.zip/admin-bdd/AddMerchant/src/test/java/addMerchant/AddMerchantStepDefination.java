package addMerchant;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.AddMerchantPageFactory;



public class AddMerchantStepDefination {

	private WebDriver driver;
	private AddMerchantPageFactory addMerchant;
	
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver","D:\\Users\\nikallur\\Desktop\\codes\\module-4\\jars\\chromedriver.exe" );
	}
	
	
	@Given("^user is on 'add merchant' page$")
	public void user_is_on_add_merchant_page() throws Throwable {
		driver = new ChromeDriver();
		driver.get("http://localhost:4200");
		addMerchant = new AddMerchantPageFactory();
		PageFactory.initElements(driver, addMerchant);   
	}

	@When("^user enters loads the page$")
	public void user_enters_loads_the_page() throws Throwable {
	   
	}

	@Then("^valid page should open$")
	public void valid_page_should_open() throws Throwable {
		String expectedPageTitle="add merchant";
		String actualPageTitle=driver.getTitle();
		Assert.assertEquals(expectedPageTitle, actualPageTitle);
		driver.close();
	}

	@When("^user enters invalid name$")
	public void user_enters_invalid_name() throws Throwable {
		addMerchant.setName("");
		addMerchant.setMobile("");
	}

	@Then("^displays '\\*Name is required'$")
	public void displays_Name_is_required() throws Throwable {
		String expectedMessage="*Name is required";
		String actualMessage=addMerchant.getNameError().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();
	}

	@When("^user enters invalid mobile number$")
	public void user_enters_invalid_mobile_number() throws Throwable {
		addMerchant.setName("Nitheesh");
		addMerchant.setMobile("12");
		addMerchant.setMail("");
	}

	@Then("^displays '\\*(\\d+) digit mobile number required'$")
	public void displays_digit_mobile_number_required(int arg1) throws Throwable {
		String expectedMessage="*10 digit mobile number required";
		String actualMessage=addMerchant.getMobileError().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();
	}

	@When("^user enters invalid mail$")
	public void user_enters_invalid_mail() throws Throwable {
		addMerchant.setName("Nitheesh");
		addMerchant.setMobile("8555019438");
		addMerchant.setMail("k");
		addMerchant.setAddress("");
	}

	@Then("^displays '\\*valid Mail Id required'$")
	public void displays_valid_Mail_Id_required() throws Throwable {
		String expectedMessage="*valid Mail Id required";
		String actualMessage=addMerchant.getMailError().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();
	}

	@When("^user enters invalid address$")
	public void user_enters_invalid_address() throws Throwable {
		addMerchant.setName("Nitheesh");
		addMerchant.setMobile("8555019438");
		addMerchant.setMail("k@gmail.com");
		addMerchant.setAddress("");
		addMerchant.setName("Nitheesh");
	}

	@Then("^displays '\\*address required'$")
	public void displays_address_required() throws Throwable {
		String expectedMessage="*address required";
		String actualMessage=addMerchant.getAddressError().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();
	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {

		addMerchant.setName("Nitheesh");
		addMerchant.setMobile("8555019438");
		addMerchant.setMail("k@gmail.com");
		addMerchant.setAddress("hyd");
		addMerchant.clickButton();
	
	}

	@Then("^displays 'merchant added successfully\\.'$")
	public void displays_merchant_added_successfully() throws Throwable {
		String expectedMessage="merchant added successfully.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();

	}
	
	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
		addMerchant.setEmail("h");
		addMerchant.setDiscription("");
	}

	@Then("^displays '\\*valid Email Id required'$")
	public void displays_valid_Email_Id_required() throws Throwable {
		String expectedMessage="*valid Email Id required";
		String actualMessage=addMerchant.getAddressError().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();
	}

	@When("^user did not enter discription$")
	public void user_did_not_enter_discription() throws Throwable {
		addMerchant.setEmail("h@gmail.com");
		addMerchant.setDiscription("");
		addMerchant.setEmail("h@gmail.com");
	}

	@Then("^displays '\\*discription needed'$")
	public void displays_discription_needed() throws Throwable {
		String expectedMessage="*discription needed";
		String actualMessage=addMerchant.getAddressError().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();
	}
	
	@When("^user entered invitation$")
	public void user_entered_invitation() throws Throwable {
		addMerchant.setEmail("h@gmail.com");
		addMerchant.setDiscription("hii h");
		addMerchant.sentButton();
	}

	@Then("^displays 'invitation sent successfully\\.\\.\\.!!!'$")
	public void displays_invitation_sent_successfully() throws Throwable {
		String expectedMessage="invitation sent successfully...!!!";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
}
