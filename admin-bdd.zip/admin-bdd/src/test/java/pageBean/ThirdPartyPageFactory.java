package pageBean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ThirdPartyPageFactory {
	@FindBy(xpath = "/html/body/app-root/html/body/form/div/div[2]/div/div[1]/input")
	WebElement name;
	
	@FindBy(xpath = "/html/body/app-root/html/body/form/div/div[2]/div/div[2]/input")
	WebElement mobile;
	
	@FindBy(xpath = "/html/body/app-root/html/body/form/div/div[2]/div/div[3]/input")
	WebElement mail;
	
	@FindBy(xpath = "/html/body/app-root/html/body/form/div/div[2]/div/div[4]/input")
	WebElement address;
	
	@FindBy(xpath = "/html/body/app-root/html/body/form/div/div[2]/div/div[5]/div/div/button")
	WebElement add;
	
	@FindBy(xpath = "/html/body/app-root/html/body/form/div/div[2]/div/div[1]/span/p")
	WebElement nameError;
	
	@FindBy(xpath = "/html/body/app-root/html/body/form/div/div[2]/div/div[2]/span/p")
	WebElement mobileError;
	
	@FindBy(xpath = "/html/body/app-root/html/body/form/div/div[2]/div/div[3]/span/p")
	WebElement mailError;
	
	@FindBy(xpath = "/html/body/app-root/html/body/form/div/div[2]/div/div[4]/span/p")
	WebElement addressError;

	public String getName() {
		return this.name.getAttribute("value");
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public String getMobile() {
		return this.mobile.getAttribute("value");
	}

	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}

	public String getMail() {
		return this.mail.getAttribute("value");
	}

	public void setMail(String mail) {
		this.mail.sendKeys(mail);
	}

	public String getAddress() {
		return this.address.getAttribute("value");
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public void clickButton() {
		add.click();
	}

	public WebElement getNameError() {
		return nameError;
	}

	public void setNameError(WebElement nameError) {
		this.nameError = nameError;
	}

	public WebElement getMobileError() {
		return mobileError;
	}

	public WebElement getMailError() {
		return mailError;
	}

	public WebElement getAddressError() {
		return addressError;
	}

}
