import { Component } from "@angular/core";
import { merchant } from "./merchant";
import { MerchantServiceService } from "./merchant-service.service";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent {
  //merchantList: Array< merchant> = [];
  merchant: merchant;

  constructor(private merchantService: MerchantServiceService) {
    //this.merchantList= this.merchantService.merchantList
  }

  ngOnInit() {
    this.showMerchants();
  }
  showMerchants() {
    this.merchantService
      .showMerchants()
      .subscribe(data => (this.merchant = data));
    //  console.log(this.merchant);
  }
  delete(code: number) {
    this.merchantService.deleteEmployee(code).subscribe(data => {
      alert("merchant deleted successfully.");
      this.reload();
      });
     // this.reload();
      //.subscribe(data => (this.merchant = data));
    //this.employeeList= this.employeeService.EmployeeList;
  }
  reload() {
   this.showMerchants();
  }
}
