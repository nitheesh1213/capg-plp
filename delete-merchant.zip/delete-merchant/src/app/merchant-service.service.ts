import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

import { merchant } from "./merchant";
import { Observable } from "rxjs/internal/Observable";

@Injectable({
  providedIn: "root"
})
export class MerchantServiceService {
  constructor(private httpClient: HttpClient) {} //this.showMerchants().subscribe(data => this.merchantList = data);}
  // merchantList:Array<merchant>=[];

baseUrl = 'http://localhost:8050/products';


  public showMerchants(): Observable<any> {
    //console.log("http://localhost:8050/merchants");
    return this.httpClient.get<any>("http://localhost:8050/merchants");
  }

  public deleteEmployee(id: number): Observable<void> {
    console.log(id);

    return this.httpClient.delete<void>(`${this.baseUrl}/${id}`)
   
  }
}

// return this.httpClient.delete<number>(
// "http://localhost:8050/products/" + id
//);
