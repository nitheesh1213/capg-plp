export class merchant
{
    id: number;
 mname: string;
 mmobile : number;
 mmail:string;
 maddress:string;
 
}