import { Component, OnInit } from '@angular/core';
import { merchant } from './merchant';
import { MerchantService } from './merchant-service.service';
import { invitation } from './invitation';
import { FormGroup, FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{

  userform : FormGroup = new FormGroup({
    
    mname  : new FormControl("",[Validators.required]),
    mmobile  : new FormControl("",[Validators.required]),
    mmail  : new FormControl("",[Validators.required]),
    maddress  : new FormControl("",[Validators.required]),
    
  });

  myform : FormGroup = new FormGroup({
    
   
    mail  : new FormControl("",[Validators.required]),
    discription  : new FormControl("",[Validators.required])
  });

 merchant1 : merchant;
 invitation1 : invitation;
constructor(private merchantService:MerchantService) 
{  this.merchant1 =new merchant();
  this.invitation1 =new invitation();
}
   
  ngOnInit() {
   
  }

  addMerchant(data):void {console.log(data)
    this.merchant1.mname=data.mname;
    this.merchant1.mmobile=data.mmobile;
    this.merchant1.mmail=data.mmail;
    this.merchant1.maddress=data.maddress;
    console.log(this.merchant1);
    this.merchantService.addMerchants(this.merchant1).subscribe(data => {
      
        alert("merchant added successfully.");
      
      });
}

sendInvitation(data1):void {console.log(data1)
  this.invitation1.mail=data1.mail;
  this.invitation1.discription=data1.discription;
  console.log(this.invitation1);
  this.merchantService.sendInvitation(this.invitation1).subscribe(data1 => {
    alert("invitation sent successfully...!!!");
  })
}
}
