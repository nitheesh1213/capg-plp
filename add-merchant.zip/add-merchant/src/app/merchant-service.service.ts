import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { merchant } from './merchant';
import { invitation } from './invitation';
@Injectable({
  providedIn: 'root'
})
export class MerchantService {

 constructor(private httpClient:HttpClient) { }

 public addMerchants(merchant1) {
  return this.httpClient.post<merchant>("http://localhost:8050/AddMerchant", merchant1)
  }

  public sendInvitation(invitation) {console.log(invitation);
    return this.httpClient.post<invitation>("http://localhost:8090/sentInvitation", invitation)
    }
}
