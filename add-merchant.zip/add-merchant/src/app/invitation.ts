export class invitation
{
 
 mail:string;
 discription:string;
 
}