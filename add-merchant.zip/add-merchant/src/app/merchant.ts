export class merchant
{
 mname: string;
 mmobile : number;
 mmail:string;
 maddress:string;
 
}
