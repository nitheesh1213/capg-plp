package com.invitation.service;

import java.util.List;

import com.customer.exception.CustomerException;
import com.invitation.bean.Invitation;

public interface InvitationService {

	public List<Invitation> sentInvitation(Invitation inv) throws CustomerException;
//	public Invitation getCustomerById(int Id) throws CustomerException;
//	public void deleteCustomer (int id) throws CustomerException;
//	public List<Invitation> getAllCustomer() throws CustomerException;
//	public List<Invitation> getCustomerByCity(String city) throws CustomerException;
//	public List<Invitation> updateCustomer(int id, Invitation cust) throws CustomerException;
//	
//	
}
