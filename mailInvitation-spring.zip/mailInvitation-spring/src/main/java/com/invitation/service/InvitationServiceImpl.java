package com.invitation.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customer.exception.CustomerException;
import com.invitation.bean.Invitation;
import com.invitation.dao.InvitationDao;
@Service
public class InvitationServiceImpl implements InvitationService {
	@Autowired
	InvitationDao customerdao;

	
	
	@Override
	public List<Invitation> sentInvitation(Invitation inv) throws CustomerException {
		 try {
		        customerdao.save(inv);
		        return customerdao.findAll();
		        }catch(Exception e) {
		            throw new CustomerException(e.getMessage());
		        }
		        }

//	@Override
//	public Invitation getCustomerById(int id) throws CustomerException {
//	try
//	{
//		return customerdao.findById(id).get();
//	}
//	catch (Exception ex)
//	{
//		throw new CustomerException(ex.getMessage());
//	}
//	}
//
//	@Override
//	public void deleteCustomer(int id) throws CustomerException {
//		try
//		{
//			customerdao.deleteById(id);
//		}
//		catch(Exception e)
//		{
//			throw new CustomerException(e.getMessage());
//		}
//		
//	}
//
//	@Override
//	public List<Invitation> getAllCustomer() throws CustomerException {
//		try
//		{
//			return customerdao.findAll();
//		}
//		catch(Exception e)
//		{
//			throw new CustomerException(e.getMessage());
//		}
//	}
//
//	@Override
//	public List<Invitation> getCustomerByCity(String city) throws CustomerException {
//		// TODO Auto-generated method stub
//		try
//		{
//		return customerdao.getCustomerByCity(city);	
//		}
//		catch(Exception e) {
//		throw new CustomerException(e.getMessage());
//	}
//	}
//
//	@Override
//	public List<Invitation> updateCustomer(int id, Invitation cust) throws CustomerException {
//		try
//		{
//			Optional<Invitation> optional=customerdao.findById(id);
//			if(optional.isPresent())
//			{
//				Invitation customer=optional.get();
//				customer.setType(cust.getType());
//				customer.setCity(cust.getCity());
//				customerdao.save(customer);
//				return getAllCustomer();
//			}
//			else
//			{
//				throw new CustomerException("Customer with Id"+id+" does not exist");	
//			}
//		}
//			catch(Exception e) {
//	            throw new CustomerException(e.getMessage());
//			
//	}
//	}

	
	}



