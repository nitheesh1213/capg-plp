package com.addthirdparty.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.addthirdparty.bean.Addthirdparty;
@Repository
public interface AddthirdpartyDao extends JpaRepository<Addthirdparty, Integer> {
	

	
}
