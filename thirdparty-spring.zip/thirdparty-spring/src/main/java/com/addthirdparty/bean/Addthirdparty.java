package com.addthirdparty.bean;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Entity
public class Addthirdparty implements Serializable {
	
	@Id
	@GeneratedValue
	private int mid;
	private String tmname;
	private long tmmobile;
	private String tmmail;
	private String tmaddress;
	
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public String getTmname() {
		return tmname;
	}
	public void setTmname(String tmname) {
		this.tmname = tmname;
	}
	public long getTmmobile() {
		return tmmobile;
	}
	public void setTmmobile(long tmmobile) {
		this.tmmobile = tmmobile;
	}
	public String getTmmail() {
		return tmmail;
	}
	public void setTmmail(String tmmail) {
		this.tmmail = tmmail;
	}
	public String getTmaddress() {
		return tmaddress;
	}
	public void setTmaddress(String tmaddress) {
		this.tmaddress = tmaddress;
	}
	@Override
	public String toString() {
		return "Addthirdparty [id=" + mid + ", tmname=" + tmname + ", tmmobile=" + tmmobile + ", tmmail=" + tmmail
				+ ", tmaddress=" + tmaddress + "]";
	}
	
	
}
