package com.addthirdparty.exception;

public class AddthirdpartytException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public AddthirdpartytException()
	{
		super();
	}
	public AddthirdpartytException(String message)
	{
		super(message);
	}
	

}
