package com.addthirdparty.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.addthirdparty.bean.Addthirdparty;

import com.addthirdparty.exception.AddthirdpartytException;
import com.addthirdparty.service.IAddthirdpartytService;

@CrossOrigin("http://localhost:4500")
@RestController
public class AddthirdpartyController {
	@Autowired
	IAddthirdpartytService thirdpartyService;
	
	@RequestMapping("/getdetails")
	public List<Addthirdparty> getAllProducts() throws AddthirdpartytException
	{
		return thirdpartyService.getAllProducts();
	}
	@RequestMapping(value="/adddetails", method=RequestMethod.POST)
	public void thirdparty(@RequestBody Addthirdparty merchant) throws AddthirdpartytException{
		thirdpartyService.createProduct(merchant);
			}
	
	@RequestMapping(value = "/products/{id}", method = RequestMethod.DELETE)
	public void deleteProduct(@PathVariable int mid) throws AddthirdpartytException {
		System.out.println("inside deletemapping of Addmerchantcontroller");
		thirdpartyService.deleteProduct(mid);
		
	}
	
//	@RequestMapping(value="/detailsbyid/{mid}", method=RequestMethod.GET)
//	public List<Products> getProductById(@PathVariable int mid) throws AddthirdpartytException{
//	return thirdpartyService.getProductByMid(mid);
//    }
//	
//	@RequestMapping("/getdet")
//	public List<Products> getAll() throws AddthirdpartytException
//	{
//		return thirdpartyService.getAll();
//	}
//	
//	@RequestMapping(value="/addp", method=RequestMethod.POST)
//	public List<Products> thirdpartyy(@RequestBody Products product) throws AddthirdpartytException{
//		return thirdpartyService.addProduct(product);
//			}
//	@RequestMapping("/detailsbyid/{id}")
//	public Product getProductById(@PathVariable String id) throws ProductException{
//	return thirdpartyService.getProductById(id);
//    }
	

//	@DeleteMapping("/products/{id}")	
//	public ResponseEntity<String> deleteProduct(@PathVariable int id) throws ProductException {
//		thirdpartyService.deleteProduct(id);
//	return new ResponseEntity<String> ("Product with"+id+" deleted",HttpStatus.OK);
//	}
	
//	@PutMapping("/products/{id}")
//	public List <Product> updateProduct(@PathVariable String id, @RequestBody Product product) throws ProductException{
//		return thirdpartyService.updateProduct(id, product);
//	}
//	
}