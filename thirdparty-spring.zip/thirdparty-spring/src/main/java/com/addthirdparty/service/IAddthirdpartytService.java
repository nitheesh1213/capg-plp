package com.addthirdparty.service;

import java.util.List;

import com.addthirdparty.bean.Addthirdparty;

import com.addthirdparty.exception.AddthirdpartytException;

public interface IAddthirdpartytService {

	public List<Addthirdparty> createProduct(Addthirdparty pro) throws AddthirdpartytException;
	//public Product getProductById(int id) throws ProductException;
	public void deleteProduct (int mid) throws AddthirdpartytException;
	public List<Addthirdparty> getAllProducts() throws AddthirdpartytException;
	//public List<Product> updateProduct(int id, Product product) throws ProductException;
//	public List<Products> getProductByMid(int mid) throws AddthirdpartytException;
//	public List<Products> getAll() throws AddthirdpartytException;
//	public List<Products> addProduct(Products pro) throws AddthirdpartytException;
}
