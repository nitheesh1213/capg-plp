package com.addthirdparty.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.addthirdparty.bean.Addthirdparty;

import com.addthirdparty.dao.AddthirdpartyDao;

import com.addthirdparty.exception.AddthirdpartytException;

@Service
public class AddthirdpartyServiceImpl implements IAddthirdpartytService {
	@Autowired
	AddthirdpartyDao AddthirdpartyDao;	
//	@Autowired
//	ProductsDao productsDao;
//	
	@Override
	public List<Addthirdparty> createProduct(Addthirdparty product) throws AddthirdpartytException {
		try {
			 AddthirdpartyDao.save(product);
		        return AddthirdpartyDao.findAll();
		        }catch(Exception exception) {
		            throw new AddthirdpartytException(exception.getMessage());
		        }
	}

	@Override
	public void deleteProduct(int mid) throws AddthirdpartytException {
		try
		{
			AddthirdpartyDao.deleteById(mid);
			
		}
		catch(Exception exception)
		{
			throw new AddthirdpartytException(exception.getMessage());
		}
		
	}
//	
	@Override
	public List<Addthirdparty> getAllProducts() throws AddthirdpartytException {
		try
		{
			return AddthirdpartyDao.findAll();
		}
		catch(Exception exception)
		{
			throw new AddthirdpartytException(exception.getMessage());
		}
	}
	
//	@Override
//	public List<Products> getProductByMid(int mid) throws AddthirdpartytException {
//		try
//		{
//			return productsDao.findByMid(mid);
//		}
//		catch (Exception exception)
//		{
//			throw new AddthirdpartytException(exception.getMessage());
//		}
//		
//	}
//	
//	@Override
//	public List<Products> getAll() throws AddthirdpartytException {
//		try
//		{
//			return productsDao.findAll();
//		}
//		catch(Exception exception)
//		{
//			throw new AddthirdpartytException(exception.getMessage());
//		}
//	}
//
//	
//	@Override
//	public List<Products> addProduct(Products product) throws AddthirdpartytException {
//		try {
//			 productsDao.save(product);
//		        return productsDao.findAll();
//		        }catch(Exception exception) {
//		            throw new AddthirdpartytException(exception.getMessage());
//		        }
//	}
//	@Override
//	public List<Product> updateProduct(int id, Product product1) throws ProductException {
//		try
//		{
//			Optional<Product> optional=AddthirdpartyDao.findById(id);
//			if(optional.isPresent())
//			{
//				Product product=optional.get();
//				product.setName(product1.getName());
//				product.setModel(product1.getModel());
//				product.setPrice(product1.getPrice());
//				AddthirdpartyDao.save(product);
//				return getAllProducts();
//			}
//			else
//			{
//				throw new ProductException("Product with"+id+" not exist");	
//			}
//		}
//			catch(Exception exception) {
//	            throw new ProductException(exception.getMessage());
//			
//	}
//	}
}



