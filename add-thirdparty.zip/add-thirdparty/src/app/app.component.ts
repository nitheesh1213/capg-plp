import { Component, OnInit } from '@angular/core';
import { merchant } from './merchant';
import { ThirdpartyServiceService } from './thirdparty-service.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{

  merchant1 : merchant;
 constructor(private merchantService:ThirdpartyServiceService) 
 {  this.merchant1 =new merchant();}
    
   ngOnInit() {
   }
 
   addMerchant(data):void {console.log(data)
     this.merchant1.tmname=data.tmname;
     this.merchant1.tmmobile=data.tmmobile;
     this.merchant1.tmmail=data.tmmail;
     this.merchant1.tmaddress=data.tmaddress;
     console.log(this.merchant1);
     this.merchantService.addMerchants(this.merchant1).subscribe(data => {
     alert("merchant added successfully.");
     });
 }
}
