import { TestBed } from '@angular/core/testing';

import { ThirdpartyServiceService } from './thirdparty-service.service';

describe('ThirdpartyServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ThirdpartyServiceService = TestBed.get(ThirdpartyServiceService);
    expect(service).toBeTruthy();
  });
});
