import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { merchant } from './merchant';

@Injectable({
  providedIn: 'root'
})
export class ThirdpartyServiceService {

  constructor(private httpClient:HttpClient) { }

 public addMerchants(merchant1) {console.log(merchant1);
  return this.httpClient.post<merchant>("http://localhost:8060/adddetails", merchant1)
  }
}
