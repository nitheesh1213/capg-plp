export class merchant
{
 tmname: string;
 tmmobile : number;
 tmmail:string;
 tmaddress:string;
 
}