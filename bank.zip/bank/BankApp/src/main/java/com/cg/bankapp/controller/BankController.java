package com.cg.bankapp.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.bankapp.bean.Bank;
import com.cg.bankapp.exception.BankException;
import com.cg.bankapp.service.BankService;


@CrossOrigin(origins="http://localhost:4040")
@RestController
public class BankController 
{
@Autowired
BankService bankService;


@RequestMapping(value="/user/add" ,method=RequestMethod.POST)
public Bank addBankAccount(@RequestBody Bank bank) throws BankException
{
	
	return bankService.addBankAccount(bank);
	 //return new ResponseEntity<String>("Your Account Id is "+bank.getAccountId()+"", HttpStatus.OK);
}

@RequestMapping("/user/show/{accountId}")
public double showBalance(@PathVariable int accountId) throws BankException
{
	return bankService.showBalance(accountId);
}

@RequestMapping(value="/user/deposit/{accountId}/{deposit}",method=RequestMethod.PUT)
public double depositAmount(@PathVariable Integer accountId,@PathVariable Integer deposit) throws BankException{
	try {
		 bankService.depositAmount(accountId, deposit);
		return 1;
}
	catch(Exception ex)
	{
		return 0;
	} 
	
}

@RequestMapping(value="/user/withdraw/{accountId}/{withdraw}",method=RequestMethod.PUT)
public  double withdrawAmount(@PathVariable Integer accountId,@PathVariable Integer withdraw) throws BankException
{
	try {
		bankService.withdrawAmount(accountId, withdraw);
		return 1;
}
	catch(Exception ex)
	{
		return 0;
	}
}
@RequestMapping(value="/user/transfer/{source}/{destination}/{money}",method=RequestMethod.GET)
public  int cashTransfer(@PathVariable int source,@PathVariable int destination,@PathVariable double money) throws BankException
{
	try {
		bankService.cashTransfer(source, destination, money);
		return 1;
	}
	catch(Exception ex)
	{
		return 0;
	}

}}
